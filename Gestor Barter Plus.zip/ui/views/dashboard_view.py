from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFrame, QLabel, QTableWidget,
    QTableWidgetItem, QHeaderView, QPushButton, QScrollArea, QTextBrowser
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QColor
from services.dashboard_service import DashboardService


class DataLoaderThread(QThread):
    datos_cargados = pyqtSignal(dict)

    def run(self):
        try:
            datos = {
                "liquidez": DashboardService.obtener_liquidez_neta(),
                "deuda_prov": DashboardService.obtener_deuda_proveedores(),
                "valores_inventario": DashboardService.obtener_valor_inventario(),
                "ventas_mes": DashboardService.obtener_ventas_del_mes(),
                "ticket_prom": DashboardService.obtener_ticket_promedio(),
                "cuentas_cobrar": DashboardService.obtener_cuentas_a_cobrar(),
                "utilidad_bruta": DashboardService.obtener_utilidad_bruta_mes(),
                "desc_data": DashboardService.obtener_analisis_descuentos(),
                "gastos_data": DashboardService.obtener_incidencia_gastos(),
                "top_productos": DashboardService.obtener_top_productos_mes(),
                "peores": DashboardService.obtener_peores_productos(),
                "deudores": DashboardService.obtener_ranking_deudores(),
                "alertas": DashboardService.obtener_alertas_stock()
            }
            self.datos_cargados.emit(datos)
        except Exception as e:
            print(f"Error cargando dashboard: {e}")
            # En un entorno real se podría emitir una señal de error, pero dejemos pasar silencio aquí para evitar crashear.
            self.datos_cargados.emit({})


class DashboardView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.cargar_datos()

    def _crear_tarjeta_kpi(self, titulo: str, color_valor: str) -> tuple[QFrame, QLabel]:
        frame = QFrame()
        frame.setStyleSheet("""
            QFrame {
                background-color: #2c3e50;
                border-radius: 8px;
                border: 1px solid #34495e;
            }
            QLabel {
                color: #ecf0f1;
                font-weight: bold;
            }
        """)
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(5, 5, 5, 5)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        lbl_titulo = QLabel(titulo)
        lbl_titulo.setStyleSheet("font-size: 11px;")
        lbl_titulo.setAlignment(Qt.AlignmentFlag.AlignCenter)

        lbl_valor = QLabel("$ 0.00")
        lbl_valor.setStyleSheet(f"color: {color_valor}; font-size: 18px; font-weight: bold;")
        lbl_valor.setAlignment(Qt.AlignmentFlag.AlignCenter)

        lay.addWidget(lbl_titulo)
        lay.addWidget(lbl_valor)

        return frame, lbl_valor

    def setup_ui(self):
        layout = QVBoxLayout()

        # Header con botón actualizar
        header_lay = QHBoxLayout()
        lbl_header = QLabel("Dashboard Gerencial")
        lbl_header.setStyleSheet("font-size: 24px; font-weight: bold;")

        btn_actualizar = QPushButton("Actualizar Datos")
        btn_actualizar.setStyleSheet("background-color: #2980b9; color: white; font-weight: bold; padding: 8px;")
        btn_actualizar.clicked.connect(self.cargar_datos)

        header_lay.addWidget(lbl_header)
        header_lay.addStretch()
        header_lay.addWidget(btn_actualizar)
        layout.addLayout(header_lay)

        # Tarjetas KPI (Grid)
        grid_kpi = QGridLayout()

        self.card_liquidez_frame, self.lbl_liquidez = self._crear_tarjeta_kpi("Liquidez Neta", "#2ecc71")
        self.card_deuda_prov_frame, self.lbl_deuda_prov = self._crear_tarjeta_kpi("Deuda a Proveedores", "#e74c3c")
        self.card_cobrar_frame, self.lbl_cobrar = self._crear_tarjeta_kpi("Cuentas a Cobrar", "#f1c40f")

        # Nuevos de Inventario
        self.card_inventario_costo, self.lbl_inventario_costo = self._crear_tarjeta_kpi("Cap. Inmov. (Costo)", "#e67e22")
        self.card_inventario_venta, self.lbl_inventario_venta = self._crear_tarjeta_kpi("Valor Potencial (Venta)", "#2980b9")
        self.card_inventario_ganancia, self.lbl_inventario_ganancia = self._crear_tarjeta_kpi("Ganancia Latente", "#8e44ad")

        self.card_ventas_frame, self.lbl_ventas = self._crear_tarjeta_kpi("Ventas del Mes", "#3498db")
        self.card_ticket_prom_frame, self.lbl_ticket_prom = self._crear_tarjeta_kpi("Ticket Promedio", "#1abc9c")
        self.card_utilidad_frame, self.lbl_utilidad = self._crear_tarjeta_kpi("Utilidad Bruta Est.", "#f39c12")
        self.card_descuentos_frame, self.lbl_descuentos = self._crear_tarjeta_kpi("Fuga por Descuentos", "#e67e22")
        self.card_gastos_frame, self.lbl_gastos = self._crear_tarjeta_kpi("Incidencia Op. (Gastos)", "#e74c3c")

        # Fila 0
        grid_kpi.addWidget(self.card_liquidez_frame, 0, 0)
        grid_kpi.addWidget(self.card_deuda_prov_frame, 0, 1)
        grid_kpi.addWidget(self.card_cobrar_frame, 0, 2)
        grid_kpi.addWidget(self.card_inventario_costo, 0, 3)

        # Fila 1
        grid_kpi.addWidget(self.card_inventario_venta, 1, 0)
        grid_kpi.addWidget(self.card_inventario_ganancia, 1, 1)
        grid_kpi.addWidget(self.card_ventas_frame, 1, 2)
        grid_kpi.addWidget(self.card_utilidad_frame, 1, 3)

        # Fila 2
        grid_kpi.addWidget(self.card_ticket_prom_frame, 2, 0)
        grid_kpi.addWidget(self.card_descuentos_frame, 2, 1)
        grid_kpi.addWidget(self.card_gastos_frame, 2, 2)

        layout.addLayout(grid_kpi)

        # Tablas de Análisis Inferiores (Grid 2x2)
        grid_tablas = QGridLayout()

        # Tabla 1: Top 10 Mayor Rotación
        frame_1 = QFrame()
        lay_1 = QVBoxLayout(frame_1)
        lbl_1 = QLabel("Top 10 Mayor Rotación (Mes)")
        lbl_1.setStyleSheet("font-weight: bold; font-size: 14px;")
        self.tbl_top_rotacion = QTableWidget(0, 3)
        self.tbl_top_rotacion.setHorizontalHeaderLabels(["Código", "Producto", "Cant. Vendida"])
        self.tbl_top_rotacion.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_top_rotacion.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tbl_top_rotacion.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_top_rotacion.setColumnWidth(0, 100)
        self.tbl_top_rotacion.setColumnWidth(2, 100)
        self.tbl_top_rotacion.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl_top_rotacion.setAlternatingRowColors(True)
        lay_1.addWidget(lbl_1)
        lay_1.addWidget(self.tbl_top_rotacion)

        # Tabla 2: Top 10 Capital Estancado
        frame_2 = QFrame()
        lay_2 = QVBoxLayout(frame_2)
        lbl_2 = QLabel("Top 10 Capital Estancado")
        lbl_2.setStyleSheet("font-weight: bold; font-size: 14px; color: #e67e22;")
        self.tbl_peores = QTableWidget(0, 4)
        self.tbl_peores.setHorizontalHeaderLabels(["Código", "Producto", "Stock Actual", "Cant. Vendida"])
        self.tbl_peores.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_peores.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.tbl_peores.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_peores.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_peores.setColumnWidth(0, 100)
        self.tbl_peores.setColumnWidth(2, 80)
        self.tbl_peores.setColumnWidth(3, 80)
        self.tbl_peores.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl_peores.setAlternatingRowColors(True)
        lay_2.addWidget(lbl_2)
        lay_2.addWidget(self.tbl_peores)

        # Tabla 3: Ranking de Deudores
        frame_3 = QFrame()
        lay_3 = QVBoxLayout(frame_3)
        lbl_3 = QLabel("Ranking de Deudores")
        lbl_3.setStyleSheet("font-weight: bold; font-size: 14px; color: #c0392b;")
        self.tbl_deudores = QTableWidget(0, 3)
        self.tbl_deudores.setHorizontalHeaderLabels(["Cliente", "Teléfono", "Saldo Deudor"])
        self.tbl_deudores.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl_deudores.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_deudores.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_deudores.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl_deudores.setAlternatingRowColors(True)
        lay_3.addWidget(lbl_3)
        lay_3.addWidget(self.tbl_deudores)

        # Tabla 4: Alerta de Quiebre de Stock
        frame_4 = QFrame()
        lay_4 = QVBoxLayout(frame_4)
        lbl_4 = QLabel("Alerta de Quiebre de Stock")
        lbl_4.setStyleSheet("font-weight: bold; font-size: 14px; color: #e74c3c;")
        self.tbl_alertas_stock = QTableWidget(0, 3)
        self.tbl_alertas_stock.setHorizontalHeaderLabels(["Producto", "Stock Actual", "Stock Mínimo"])
        self.tbl_alertas_stock.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl_alertas_stock.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_alertas_stock.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_alertas_stock.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl_alertas_stock.setAlternatingRowColors(True)
        lay_4.addWidget(lbl_4)
        lay_4.addWidget(self.tbl_alertas_stock)

        grid_tablas.addWidget(frame_1, 0, 0)
        grid_tablas.addWidget(frame_2, 0, 1)
        grid_tablas.addWidget(frame_3, 1, 0)
        grid_tablas.addWidget(frame_4, 1, 1)


        # Panel Principal Contenedor
        main_h_lay = QHBoxLayout()
        main_h_lay.addLayout(grid_tablas, stretch=4)

        layout.addLayout(main_h_lay)

        # Configurar Scroll Area principal
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_content.setLayout(layout)
        scroll_area.setWidget(self.scroll_content)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(scroll_area)

        

    def cargar_datos(self):
        self.btn_actualizar.setEnabled(False)
        self.btn_actualizar.setText("Actualizando...")
        
        self.loader_thread = DataLoaderThread()
        self.loader_thread.datos_cargados.connect(self._on_datos_cargados)
        self.loader_thread.start()

    def _on_datos_cargados(self, datos: dict):
        self.btn_actualizar.setEnabled(True)
        self.btn_actualizar.setText("Actualizar Métricas")
        
        if not datos:
            return

        liquidez = datos.get("liquidez", 0.0)
        deuda_prov = datos.get("deuda_prov", 0.0)
        valores_inventario = datos.get("valores_inventario", {"capital_invertido": 0.0, "valor_venta_publico": 0.0})
        ventas_mes = datos.get("ventas_mes", 0.0)
        ticket_prom = datos.get("ticket_prom", 0.0)
        cuentas_cobrar = datos.get("cuentas_cobrar", 0.0)
        utilidad_bruta = datos.get("utilidad_bruta", 0.0)
        desc_data = datos.get("desc_data", {'total_dinero_descontado': 0.0, 'cantidad_operaciones': 0, 'porcentaje_sobre_ventas': 0.0})
        gastos_data = datos.get("gastos_data", {'total_gastos': 0.0, 'incidencia_operativa': 0.0})

        self.lbl_liquidez.setText(f"$ {liquidez:,.2f}")
        self.lbl_liquidez.setStyleSheet(f"color: {'#2ecc71' if liquidez >= 0 else '#e74c3c'}; font-size: 24px; font-weight: bold;")
        
        self.lbl_deuda_prov.setText(f"$ {deuda_prov:,.2f}")
        
        cap_inv = valores_inventario.get("capital_invertido", 0.0)
        val_ven = valores_inventario.get("valor_venta_publico", 0.0)
        ganancia_latente = val_ven - cap_inv
        
        self.lbl_inventario_costo.setText(f"$ {cap_inv:,.2f}")
        self.lbl_inventario_venta.setText(f"$ {val_ven:,.2f}")
        self.lbl_inventario_ganancia.setText(f"$ {ganancia_latente:,.2f}")
        
        self.lbl_ventas.setText(f"$ {ventas_mes:,.2f}")
        self.lbl_ticket_prom.setText(f"$ {ticket_prom:,.2f}")
        self.lbl_cobrar.setText(f"$ {cuentas_cobrar:,.2f}")
        self.lbl_utilidad.setText(f"$ {utilidad_bruta:,.2f}")
        
        texto_desc = f"$ {desc_data['total_dinero_descontado']:,.2f}\n({desc_data['cantidad_operaciones']} ops | {desc_data['porcentaje_sobre_ventas']:.1f}%)"
        self.lbl_descuentos.setText(texto_desc)
        
        texto_gasto = f"$ {gastos_data['total_gastos']:,.2f}\n({gastos_data['incidencia_operativa']:.1f}% vs Ventas)"
        self.lbl_gastos.setText(texto_gasto)

        # Tablas
        top_productos = datos.get("top_productos", [])
        self.tbl_top_rotacion.setRowCount(len(top_productos))
        for row, prod in enumerate(top_productos):
            self.tbl_top_rotacion.setItem(row, 0, QTableWidgetItem(prod["codigo"]))
            self.tbl_top_rotacion.setItem(row, 1, QTableWidgetItem(prod["producto"]))
            item_cant = QTableWidgetItem(f"{prod['cantidad']:.2f}")
            item_cant.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tbl_top_rotacion.setItem(row, 2, item_cant)

        peores = datos.get("peores", [])
        self.tbl_peores.setRowCount(len(peores))
        for row, p in enumerate(peores):
            self.tbl_peores.setItem(row, 0, QTableWidgetItem(p["codigo"]))
            self.tbl_peores.setItem(row, 1, QTableWidgetItem(p["producto"]))
            item_stk = QTableWidgetItem(f"{p['stock']:.2f}")
            item_stk.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tbl_peores.setItem(row, 2, item_stk)
            item_vnd = QTableWidgetItem(f"{p['vendido']:.2f}")
            item_vnd.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tbl_peores.setItem(row, 3, item_vnd)

        deudores = datos.get("deudores", [])
        self.tbl_deudores.setRowCount(len(deudores))
        for row, d in enumerate(deudores):
            self.tbl_deudores.setItem(row, 0, QTableWidgetItem(d["cliente"]))
            self.tbl_deudores.setItem(row, 1, QTableWidgetItem(d["telefono"]))
            item_saldo = QTableWidgetItem(f"$ {d['saldo']:,.2f}")
            item_saldo.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            self.tbl_deudores.setItem(row, 2, item_saldo)

        alertas = datos.get("alertas", [])
        self.tbl_alertas_stock.setRowCount(len(alertas))
        for row, alerta in enumerate(alertas):
            self.tbl_alertas_stock.setItem(row, 0, QTableWidgetItem(alerta["producto"]))
            
            item_act = QTableWidgetItem(f"{alerta['stock_actual']:.2f}")
            item_act.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if alerta['stock_actual'] <= 0:
                item_act.setForeground(QColor("#e74c3c"))
            self.tbl_alertas_stock.setItem(row, 1, item_act)
            
            item_min = QTableWidgetItem(f"{alerta['stock_minimo']:.2f}")
            item_min.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tbl_alertas_stock.setItem(row, 2, item_min)


