# -*- coding: utf-8 -*-
import os
import datetime as dt

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QMessageBox, QHeaderView, QLabel, QCheckBox,
    QDialog, QFormLayout, QDoubleSpinBox, QComboBox, QFileDialog,
    QGroupBox, QSplitter, QFrame, QSpinBox, QAbstractItemView, QLineEdit
)
from PyQt6.QtCore import Qt, QSettings, QSizeF, QRectF, QTimer, QMarginsF
from PyQt6.QtGui import QColor, QPainter, QFont, QPen, QBrush, QPageLayout, QPageSize
from PyQt6.QtPrintSupport import QPrinter, QPrintDialog, QPrintPreviewWidget

from database.conexion import get_session
from database.models.producto import Producto
try:
    from database.models.producto import Marca
except ImportError:
    Marca = None

from .barcode_utils import get_code128_pattern



# =============================================================================
# Custom Dialog: Configuration + Preview + Quantity Selection
# =============================================================================

class ConfiguracionTicketDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurar Impresora de Tickets (POS)")
        self.resize(400, 200)
        
        layout = QVBoxLayout(self)
        
        form = QFormLayout()
        self.cmb_printer = QComboBox()
        
        from PyQt6.QtPrintSupport import QPrinterInfo
        printers = [p.printerName() for p in QPrinterInfo.availablePrinters()]
        self.cmb_printer.addItems(printers)
        
        self.sp_width = QDoubleSpinBox()
        self.sp_width.setRange(20, 200)
        self.sp_width.setSuffix(" mm")
        self.sp_width.setValue(58.0)
        
        form.addRow("Impresora:", self.cmb_printer)
        form.addRow("Ancho Papel:", self.sp_width)
        
        layout.addLayout(form)
        
        btn_box = QHBoxLayout()
        btn_save = QPushButton("Guardar")
        btn_save.clicked.connect(self.save_config)
        btn_box.addWidget(btn_save)
        
        layout.addLayout(btn_box)
        
        self.load_config()
        
    def load_config(self):
        settings = QSettings("BarterPlus", "TicketConfig")
        printer_name = settings.value("printer_name", "")
        idx = self.cmb_printer.findText(printer_name)
        if idx >= 0:
            self.cmb_printer.setCurrentIndex(idx)
            
        self.sp_width.setValue(float(settings.value("width", 58.0)))
        
    def save_config(self):
        settings = QSettings("BarterPlus", "TicketConfig")
        settings.setValue("printer_name", self.cmb_printer.currentText())
        settings.setValue("width", self.sp_width.value())
        QMessageBox.information(self, "Éxito", "Configuración de Tickets guardada.")
        self.accept()

class EtiquetasPreviewDialog(QDialog):
    def __init__(self, items, parent=None):
        """
        items: list of dicts with {id, marca, nombre, code, equivalencia, sku, cod_prov, precio}
        """
        super().__init__(parent)
        self.setWindowTitle("Configuración e Impresión de Etiquetas")
        self.resize(1100, 700)
        self.settings = QSettings("BarterPlus", "LabelConfig")

        # Internal state
        self.items = items # Original items
        # Augment items with 'cantidad'
        for it in self.items:
            it['cantidad'] = 1

        self.printer = QPrinter(QPrinter.PrinterMode.HighResolution)

        # Main Layout
        main_layout = QHBoxLayout(self)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(splitter)

        # --- LEFT PANEL: Config & Items ---
        left_widget = QWidget()
        left_lay = QVBoxLayout(left_widget)
        left_lay.setContentsMargins(0,0,0,0)

        # 1. Configuration Controls (Scrollable if needed, but fixed is fine)
        config_group = QGroupBox("Configuración de Etiqueta")
        form = QFormLayout(config_group)

        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["A4 (Grilla)", "Rollo / Térmica (Individual)"])

        # Dimensions
        hb_dim = QHBoxLayout()
        self.sp_width = QDoubleSpinBox(); self.sp_width.setRange(10, 300); self.sp_width.setSuffix(" mm"); self.sp_width.setToolTip("Ancho")
        self.sp_height = QDoubleSpinBox(); self.sp_height.setRange(10, 300); self.sp_height.setSuffix(" mm"); self.sp_height.setToolTip("Alto")
        hb_dim.addWidget(QLabel("W:")); hb_dim.addWidget(self.sp_width)
        hb_dim.addWidget(QLabel("H:")); hb_dim.addWidget(self.sp_height)

        # Offsets
        hb_off = QHBoxLayout()
        self.sp_off_x = QDoubleSpinBox(); self.sp_off_x.setRange(-50, 50); self.sp_off_x.setSuffix(" mm"); self.sp_off_x.setToolTip("Desfase Horizontal (X)")
        self.sp_off_y = QDoubleSpinBox(); self.sp_off_y.setRange(-50, 50); self.sp_off_y.setSuffix(" mm"); self.sp_off_y.setToolTip("Desfase Vertical (Y)")
        hb_off.addWidget(QLabel("X:")); hb_off.addWidget(self.sp_off_x)
        hb_off.addWidget(QLabel("Y:")); hb_off.addWidget(self.sp_off_y)

        # Font Scale
        self.sp_font_scale = QDoubleSpinBox(); self.sp_font_scale.setRange(0.1, 5.0); self.sp_font_scale.setSingleStep(0.1)

        # Fields
        self.chk_marca = QCheckBox("Marca")
        self.chk_nombre = QCheckBox("Nombre")
        self.chk_codigo = QCheckBox("Código Barras")
        self.chk_equivalencia = QCheckBox("Equivalencia")
        self.chk_sku = QCheckBox("SKU")
        self.chk_precio = QCheckBox("Precio")

        # Layout Config
        form.addRow("Modo:", self.cmb_mode)
        form.addRow("Tamaño:", hb_dim)
        form.addRow("Desfase (Centro):", hb_off)
        form.addRow("Escala Fuente:", self.sp_font_scale)

        # Grid for checkboxes
        gl = QHBoxLayout() # flow
        gl.addWidget(self.chk_marca); gl.addWidget(self.chk_nombre)
        gl.addWidget(self.chk_codigo); gl.addWidget(self.chk_precio)
        form.addRow(gl)
        gl2 = QHBoxLayout()
        gl2.addWidget(self.chk_equivalencia); gl2.addWidget(self.chk_sku)
        form.addRow(gl2)

        left_lay.addWidget(config_group)

        # 2. Items Table (Qty)
        left_lay.addWidget(QLabel("<b>Items a Imprimir:</b>"))
        self.tbl_items = QTableWidget()
        self.tbl_items.setColumnCount(3)
        self.tbl_items.setHorizontalHeaderLabels(["Producto", "Cant.", ""])
        self.tbl_items.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl_items.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_items.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        left_lay.addWidget(self.tbl_items)

        # 3. Action Buttons
        btn_box = QVBoxLayout()
        hb_print = QHBoxLayout()
        self.btn_imprimir_etiqueta = QPushButton("Imprimir")
        self.btn_imprimir_etiqueta.setStyleSheet("font-weight:bold; height: 40px; background-color: #c8e6c9;")
        self.btn_imprimir_etiqueta.clicked.connect(self._print_etiquetas)

        self.btn_print_dialog = QPushButton("Seleccionar Impresora...")
        self.btn_print_dialog.setStyleSheet("height: 40px; background-color: #e0f7fa;")
        self.btn_print_dialog.clicked.connect(self._print_dialog)

        hb_print.addWidget(self.btn_print_direct)
        hb_print.addWidget(self.btn_print_dialog)
        btn_box.addLayout(hb_print)

        self.btn_pdf = QPushButton("Exportar PDF")
        self.btn_pdf.clicked.connect(self._export_pdf)
        btn_box.addWidget(self.btn_pdf)

        left_lay.addLayout(btn_box)

        # --- RIGHT PANEL: Preview ---
        self.preview = QPrintPreviewWidget(self.printer)
        self.preview.paintRequested.connect(self._paint_preview)

        splitter.addWidget(left_widget)
        splitter.addWidget(self.preview)
        splitter.setStretchFactor(1, 2) # Give preview more space

        # Load Settings
        self._load_settings()
        self._populate_table()

        # Connect signals
        for w in [self.cmb_mode, self.sp_width, self.sp_height, self.sp_font_scale,
                  self.sp_off_x, self.sp_off_y,
                  self.chk_marca, self.chk_nombre, self.chk_codigo,
                  self.chk_equivalencia, self.chk_sku, self.chk_precio]:
            if isinstance(w, QDoubleSpinBox) or isinstance(w, QSpinBox):
                w.valueChanged.connect(self._trigger_update)
            elif isinstance(w, QComboBox):
                w.currentIndexChanged.connect(self._trigger_update)
            elif isinstance(w, QCheckBox):
                w.toggled.connect(self._trigger_update)

        # Initial update
        QTimer.singleShot(100, self._trigger_update)

    def _load_settings(self):
        self.cmb_mode.setCurrentText(str(self.settings.value("mode", "A4 (Grilla)")))
        self.sp_width.setValue(float(self.settings.value("width", 50.0)))
        self.sp_height.setValue(float(self.settings.value("height", 30.0)))
        self.sp_off_x.setValue(float(self.settings.value("offset_x", 0.0)))
        self.sp_off_y.setValue(float(self.settings.value("offset_y", 0.0)))
        self.sp_font_scale.setValue(float(self.settings.value("font_scale", 1.0)))

        self.chk_marca.setChecked(self.settings.value("show_marca", True, type=bool))
        self.chk_nombre.setChecked(self.settings.value("show_nombre", True, type=bool))
        self.chk_codigo.setChecked(self.settings.value("show_codigo", True, type=bool))
        self.chk_equivalencia.setChecked(self.settings.value("show_equivalencia", False, type=bool))
        self.chk_sku.setChecked(self.settings.value("show_sku", False, type=bool))
        self.chk_precio.setChecked(self.settings.value("show_precio", False, type=bool))

    def _save_settings(self):
        self.settings.setValue("mode", self.cmb_mode.currentText())
        self.settings.setValue("width", self.sp_width.value())
        self.settings.setValue("height", self.sp_height.value())
        self.settings.setValue("offset_x", self.sp_off_x.value())
        self.settings.setValue("offset_y", self.sp_off_y.value())
        self.settings.setValue("font_scale", self.sp_font_scale.value())

        self.settings.setValue("show_marca", self.chk_marca.isChecked())
        self.settings.setValue("show_nombre", self.chk_nombre.isChecked())
        self.settings.setValue("show_codigo", self.chk_codigo.isChecked())
        self.settings.setValue("show_equivalencia", self.chk_equivalencia.isChecked())
        self.settings.setValue("show_sku", self.chk_sku.isChecked())
        self.settings.setValue("show_precio", self.chk_precio.isChecked())

    def _populate_table(self):
        self.tbl_items.setRowCount(len(self.items))
        for r, item in enumerate(self.items):
            # Name
            lbl = f"{item['nombre']}"
            if item.get('marca'): lbl = f"[{item['marca']}] {lbl}"
            self.tbl_items.setItem(r, 0, QTableWidgetItem(lbl))

            # Qty Spinbox
            sb = QSpinBox()
            sb.setRange(0, 999)
            sb.setValue(item['cantidad'])
            sb.valueChanged.connect(lambda val, idx=r: self._update_qty(idx, val))
            self.tbl_items.setCellWidget(r, 1, sb)

            # Remove btn
            btn_del = QPushButton("X")
            btn_del.setFixedWidth(24)
            btn_del.setStyleSheet("color:red; font-weight:bold;")
            btn_del.clicked.connect(lambda _, idx=r: self._remove_row(idx))
            self.tbl_items.setCellWidget(r, 2, btn_del)

    def _update_qty(self, row, val):
        if 0 <= row < len(self.items):
            self.items[row]['cantidad'] = val
            self._trigger_update()

    def _remove_row(self, row):
        if 0 <= row < len(self.items):
            self.items[row]['cantidad'] = 0 # Just mark 0 to skip printing
            self.tbl_items.hideRow(row) # Hide visually
            self._trigger_update()

    def _trigger_update(self):
        self.preview.updatePreview()

    def _apply_printer_config(self, printer):
        """Applies page size and margins to the given printer based on UI settings."""
        mode = self.cmb_mode.currentText()
        w_mm = self.sp_width.value()
        h_mm = self.sp_height.value()

        if mode.startswith("Rollo"):
            # Set custom page size for thermal printer
            size = QPageSize(QSizeF(w_mm, h_mm), QPageSize.Unit.Millimeter)
            printer.setPageSize(size)
            # Minimal margins
            printer.setPageMargins(QMarginsF(0.0, 0.0, 0.0, 0.0), QPageLayout.Unit.Millimeter)
            printer.setFullPage(True) # Force full page drawing for roll printers to avoid driver margins
        else:
            # A4
            printer.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
            printer.setFullPage(False)

    def _paint_preview(self, printer):
        # Applies to actual print or preview
        self._save_settings() # Save current UI state to settings so drawing logic can read it if needed, or pass explicitly

        self._apply_printer_config(printer)

        painter = QPainter()
        if painter.begin(printer):
            self._draw_labels(painter, printer)
            painter.end()

    def _draw_labels(self, painter, printer):
        # Generate flat list of items to print based on quantity
        print_queue = []
        for it in self.items:
            qty = it.get('cantidad', 1)
            for _ in range(qty):
                print_queue.append(it)

        if not print_queue:
            return

        mode = self.cmb_mode.currentText()

        # Coordinate system setup
        dpi = printer.resolution()
        if dpi <= 0: dpi = 96 # Fallback if invalid printer resolution

        # 1 inch = 25.4 mm
        ppm = dpi / 25.4

        # Settings
        w_mm = self.sp_width.value()
        h_mm = self.sp_height.value()
        off_x_mm = self.sp_off_x.value()
        off_y_mm = self.sp_off_y.value()

        w_px = w_mm * ppm
        h_px = h_mm * ppm
        off_x_px = off_x_mm * ppm
        off_y_px = off_y_mm * ppm

        if w_px <= 0: w_px = 100 # Prevent division by zero
        if h_px <= 0: h_px = 50

        painter.save()

        # Draw Logic
        if mode.startswith("Rollo"):
            # Use pageRect() origin to respect physical margins and apply user offsets
            page_rect = printer.pageRect(QPrinter.Unit.DevicePixel)
            start_x = page_rect.x() + off_x_px
            start_y = page_rect.y() + off_y_px
            rect = QRectF(start_x, start_y, w_px, h_px)

            for i, item in enumerate(print_queue):
                if i > 0:
                    printer.newPage()
                self._draw_single_label(painter, rect, item, ppm)
        else:
            # A4 Grid
            page_rect = printer.pageRect(QPrinter.Unit.DevicePixel)
            start_x = page_rect.x() + off_x_px
            start_y = page_rect.y() + off_y_px

            cols = int(page_rect.width() / w_px)
            rows = int(page_rect.height() / h_px)
            if cols < 1: cols = 1
            if rows < 1: rows = 1

            items_per_page = cols * rows

            for i, item in enumerate(print_queue):
                if i > 0 and i % items_per_page == 0:
                    printer.newPage()

                idx_on_page = i % items_per_page
                c = idx_on_page % cols
                r = idx_on_page // cols

                x = start_x + (c * w_px)
                y = start_y + (r * h_px)

                # Draw only if within page (using page bounds roughly)
                if (y + h_px) <= (page_rect.y() + page_rect.height() + max(0, off_y_px)):
                    rect = QRectF(x, y, w_px, h_px)
                    self._draw_single_label(painter, rect, item, ppm)

        painter.restore()

    def _draw_single_label(self, painter, rect, item, ppm):
        painter.save() # Isolate state for each label

        # Reset pen and brush before drawing text to ensure visibility
        painter.setPen(QPen(Qt.GlobalColor.black))
        painter.setBrush(Qt.BrushStyle.NoBrush)

        # Draw white background (helpful for some contexts)
        painter.fillRect(rect, Qt.GlobalColor.white)

        # Padding (approx 1mm or 2mm)
        pad = 1.0 * ppm
        inner = rect.adjusted(pad, pad, -pad, -pad)

        if inner.width() <= 0 or inner.height() <= 0:
            painter.restore()
            return

        # Settings
        font_scale = self.sp_font_scale.value()

        dpi = ppm * 25.4
        def get_font(pts, bold=False, family="Arial"):
            px_size = pts * (dpi / 72.0) * font_scale
            f = QFont(family)
            f.setPixelSize(int(px_size))
            f.setBold(bold)
            return f, int(px_size)

        y_cursor = inner.y()

        # 1. Marca
        if self.chk_marca.isChecked() and item.get('marca'):
            f, px = get_font(10, True)
            painter.setFont(f)
            fm = painter.fontMetrics()
            try:
                txt = str(item['marca']).upper()
            except:
                txt = ""
            rect_txt = QRectF(inner.x(), y_cursor, inner.width(), float(fm.height()))
            painter.drawText(rect_txt, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, txt)
            y_cursor += fm.height()

        # 2. Nombre
        if self.chk_nombre.isChecked() and item.get('nombre'):
            f, px = get_font(9, False)
            painter.setFont(f)
            fm = painter.fontMetrics()

            line_h = fm.height()
            max_h = line_h * 2

            rect_txt = QRectF(inner.x(), y_cursor, inner.width(), float(max_h))
            bounding = painter.boundingRect(rect_txt, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap, item['nombre'])

            painter.drawText(rect_txt, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap, item['nombre'])
            y_cursor += min(bounding.height(), max_h) + (1 * ppm) 

        # 3. Extras line (Code, SKU, Price)
        extras = []
        if self.chk_equivalencia.isChecked() and item.get('equivalencia'):
            extras.append(f"Eq:{item['equivalencia']}")
        if self.chk_sku.isChecked() and item.get('sku'):
            extras.append(f"SKU:{item['sku']}")
        if self.chk_precio.isChecked() and item.get('precio'):
            extras.append(f"${item['precio']:.2f}")

        if extras:
            line = " ".join(extras)
            f, px = get_font(7, False)
            painter.setFont(f)
            fm = painter.fontMetrics()
            rect_txt = QRectF(inner.x(), y_cursor, inner.width(), float(fm.height()))
            painter.drawText(rect_txt, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, line)
            y_cursor += fm.height() + (1 * ppm)

        # 4. Barcode
        if self.chk_codigo.isChecked() and item.get('code'):
            remaining = inner.bottom() - y_cursor

            f_code, px_code = get_font(8, False, "Courier New")
            painter.setFont(f_code)
            fm_code = painter.fontMetrics()
            h_text = fm_code.height()

            h_bars = remaining - h_text

            if h_bars > (2 * ppm): # Draw bars if at least 2mm space
                self._draw_bars(painter, inner.x(), y_cursor, inner.width(), h_bars, item['code'])
                y_cursor += h_bars

                painter.setPen(QPen(Qt.GlobalColor.black))
                painter.setBrush(Qt.BrushStyle.NoBrush)

                rect_txt = QRectF(inner.x(), y_cursor, inner.width(), float(h_text))
                painter.drawText(rect_txt, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, item['code'])

        painter.restore()


    def _draw_bars(self, painter, x, y, w, h, code):
        pattern = get_code128_pattern(code)
        if not pattern: return

        total_units = sum(int(c) for c in pattern)
        if total_units == 0: return

        unit_w = w / total_units

        curr_x = x
        is_bar = True

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(Qt.GlobalColor.black))

        for char in pattern:
            width_units = int(char)
            width_px = width_units * unit_w

            if is_bar:
                painter.drawRect(QRectF(curr_x, y, width_px, h))

            curr_x += width_px
            is_bar = not is_bar

    def _print_etiquetas(self):
        print_job = QPrinter(QPrinter.PrinterMode.HighResolution)
        print_job.setOutputFormat(QPrinter.OutputFormat.NativeFormat)
        
        # Opcional: guardar nombre en settings
        printer_name = self.settings.value("printer_name", "")
        if printer_name:
            print_job.setPrinterName(printer_name)
            self._apply_printer_config(print_job)
            painter = QPainter()
            if painter.begin(print_job):
                self._draw_labels(painter, print_job)
                painter.end()
            QMessageBox.information(self, "Impresión", "Enviado a la impresora.")
        else:
            dlg = QPrintDialog(print_job, self)
            if dlg.exec() == int(QDialog.DialogCode.Accepted):
                self.settings.setValue("printer_name", print_job.printerName())
                self._apply_printer_config(print_job)
                painter = QPainter()
                if painter.begin(print_job):
                    self._draw_labels(painter, print_job)
                    painter.end()

    def _print_dialog(self):
        print_job = QPrinter(QPrinter.PrinterMode.HighResolution)
        print_job.setOutputFormat(QPrinter.OutputFormat.NativeFormat)
        dlg = QPrintDialog(print_job, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._apply_printer_config(print_job)
            painter = QPainter()
            if painter.begin(print_job):
                self._draw_labels(painter, print_job)
                painter.end()

    def _export_pdf(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Exportar PDF", "", "PDF Files (*.pdf)")
        if filename:
            if not filename.endswith(".pdf"): filename += ".pdf"

            self.printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
            self.printer.setOutputFileName(filename)

            painter = QPainter()
            if painter.begin(self.printer):
                self._draw_labels(painter, self.printer)
                painter.end()
            QMessageBox.information(self, "PDF", f"Guardado en {filename}")


# =============================================================================
# Main Tab
# =============================================================================
class CodigosBarraTab(QWidget):
    def __init__(self):
        super().__init__()
        self._datos_filtro = []
        self._selected_ids = set()
        self._setup_ui()
        self._load_data()

    def _setup_ui(self):
        layout = QVBoxLayout(self)

        # Toolbar
        bar = QHBoxLayout()

        self.btn_refresh = QPushButton("Actualizar")
        self.btn_refresh.clicked.connect(self._load_data)
        bar.addWidget(self.btn_refresh)

        self.chk_solo_sin_codigo = QCheckBox("Ver solo sin código")
        self.chk_solo_sin_codigo.stateChanged.connect(self._load_data)
        bar.addWidget(self.chk_solo_sin_codigo)

        # Filtros
        self.lay_filtros = QHBoxLayout()
        self.cmb_marca = QComboBox()
        self.cmb_rubro = QComboBox()
        self.cmb_subrubro = QComboBox()
        self.chk_recientes = QCheckBox("Agregados hoy")

        self.lay_filtros.addWidget(QLabel("Marca:"))
        self.lay_filtros.addWidget(self.cmb_marca)
        self.lay_filtros.addWidget(QLabel("Rubro:"))
        self.lay_filtros.addWidget(self.cmb_rubro)
        self.lay_filtros.addWidget(QLabel("Subrubro:"))
        self.lay_filtros.addWidget(self.cmb_subrubro)
        self.lay_filtros.addWidget(self.chk_recientes)
        self.lay_filtros.addStretch()

        layout.addLayout(self.lay_filtros)

        self.cmb_marca.currentIndexChanged.connect(self._aplicar_filtros)
        self.cmb_rubro.currentIndexChanged.connect(self._aplicar_filtros)
        self.cmb_subrubro.currentIndexChanged.connect(self._aplicar_filtros)
        self.chk_recientes.stateChanged.connect(self._aplicar_filtros)

        bar.addStretch()

        self.btn_imprimir = QPushButton("Imprimir / Vista Previa")
        self.btn_imprimir.setStyleSheet("font-weight: bold; color: blue; padding: 6px 12px;")
        self.btn_imprimir.clicked.connect(self._open_print_preview)
        bar.addWidget(self.btn_imprimir)

        self.btn_generar = QPushButton("Asignar Códigos Auto")
        self.btn_generar.clicked.connect(self._asignar_codigos_faltantes)
        bar.addWidget(self.btn_generar)

        self.btn_config_ticket_pos = QPushButton("Config. Ticket POS")
        self.btn_config_ticket_pos.setStyleSheet("color: purple; font-weight: bold;")
        self.btn_config_ticket_pos.clicked.connect(self._abrir_config_ticket)
        bar.addWidget(self.btn_config_ticket_pos)


        layout.addLayout(bar)

        # Tabla
        self.tbl = QTableWidget()
        self.tbl.setColumnCount(5)
        self.tbl.setHorizontalHeaderLabels(["Sel.", "ID", "Marca", "Producto", "Código Barras"])
        self.tbl.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.tbl.setColumnWidth(0, 40)
        self.tbl.setColumnWidth(1, 60)
        self.tbl.setColumnWidth(2, 120)
        layout.addWidget(self.tbl)

        # Controles de paginacion
        self.lay_paginacion = QHBoxLayout()
        self.btn_prev = QPushButton("< Anterior")
        self.lbl_page = QLabel("Página 1")
        self.btn_next = QPushButton("Siguiente >")
        
        self.btn_prev.clicked.connect(self._page_prev)
        self.btn_next.clicked.connect(self._page_next)
        
        self.lay_paginacion.addStretch()
        self.lay_paginacion.addWidget(self.btn_prev)
        self.lay_paginacion.addWidget(self.lbl_page)
        self.lay_paginacion.addWidget(self.btn_next)
        self.lay_paginacion.addStretch()
        
        self.current_page = 0
        self.page_size = 50
        self._filtered_indices = []

        layout.addLayout(self.lay_paginacion)

    def refresh(self):
        self._load_data()

    def _load_data(self):
        self.tbl.setRowCount(0)
        solo_sin = self.chk_solo_sin_codigo.isChecked()

        with get_session() as s:
            if Marca:
                q = s.query(Producto, Marca.nombre).outerjoin(Marca, Producto.marca_id == Marca.id).filter(Producto.activo == True)
            else:
                q = s.query(Producto).filter(Producto.activo == True)

            prods = q.all()

            rows = []
            for row in prods:
                if Marca:
                    try: p, m_nombre = row
                    except: p = row[0]; m_nombre = row[1]
                else:
                    p = row; m_nombre = ""

                cb = (p.codigo_barras or "").strip()
                if solo_sin and cb:
                    continue
                rows.append((p, m_nombre))

            self._datos_filtro = []
            for p, m_nombre in rows:
                rubro = str(getattr(p, "rubro", "") or "")
                subrubro = str(getattr(p, "subrubro", "") or "")
                creado_en = getattr(p, "creado_en", None)

                cod = ""
                for fn in ("codigo","sku","cod"):
                    if hasattr(p, fn) and getattr(p, fn):
                        cod = str(getattr(p, fn))
                        break

                cb = (getattr(p, "codigo_barras", None) or getattr(p, "barcode", None) or getattr(p, "cb", None) or getattr(p, "ean", None) or "").strip()
                
                pr = p.precio_minorista

                self._datos_filtro.append({
                    "id": p.id,
                    "codigo": cod,
                    "nombre": getattr(p, "nombre", "") or "",
                    "marca": m_nombre or "",
                    "cb": cb,
                    "rubro": rubro,
                    "subrubro": subrubro,
                    "creado_en": creado_en,
                    "precio": pr
                })

        self._actualizar_combos_filtro()

    def _actualizar_combos_filtro(self):
        m_marca = self.cmb_marca.currentText()
        m_rubro = self.cmb_rubro.currentText()
        m_subrubro = self.cmb_subrubro.currentText()

        self.cmb_marca.blockSignals(True)
        self.cmb_rubro.blockSignals(True)
        self.cmb_subrubro.blockSignals(True)

        self.cmb_marca.clear()
        self.cmb_rubro.clear()
        self.cmb_subrubro.clear()

        marcas = sorted(list(set([d["marca"] for d in self._datos_filtro if d["marca"]])))
        rubros = sorted(list(set([d["rubro"] for d in self._datos_filtro if d["rubro"]])))
        subrubros = sorted(list(set([d["subrubro"] for d in self._datos_filtro if d["subrubro"]])))

        self.cmb_marca.addItem("Todas")
        self.cmb_marca.addItems(marcas)
        self.cmb_rubro.addItem("Todos")
        self.cmb_rubro.addItems(rubros)
        self.cmb_subrubro.addItem("Todos")
        self.cmb_subrubro.addItems(subrubros)

        idx = self.cmb_marca.findText(m_marca)
        if idx >= 0: self.cmb_marca.setCurrentIndex(idx)
        idx = self.cmb_rubro.findText(m_rubro)
        if idx >= 0: self.cmb_rubro.setCurrentIndex(idx)
        idx = self.cmb_subrubro.findText(m_subrubro)
        if idx >= 0: self.cmb_subrubro.setCurrentIndex(idx)

        self.cmb_marca.blockSignals(False)
        self.cmb_rubro.blockSignals(False)
        self.cmb_subrubro.blockSignals(False)

        self._aplicar_filtros()

    def _page_prev(self):
        if self.current_page > 0:
            self.current_page -= 1
            self._render_page()

    def _page_next(self):
        max_page = max(0, (len(self._filtered_indices) - 1) // self.page_size)
        if self.current_page < max_page:
            self.current_page += 1
            self._render_page()

    def _aplicar_filtros(self):
        if not hasattr(self, '_datos_filtro'): return

        f_marca = self.cmb_marca.currentText()
        f_rubro = self.cmb_rubro.currentText()
        f_subrubro = self.cmb_subrubro.currentText()
        f_reciente = self.chk_recientes.isChecked()

        hoy = dt.datetime.now().date()

        self._filtered_indices = []
        for i, d in enumerate(self._datos_filtro):
            mostrar = True
            if f_marca != "Todas" and f_marca != "" and d.get("marca") != f_marca: mostrar = False
            if f_rubro != "Todos" and f_rubro != "" and d.get("rubro") != f_rubro: mostrar = False
            if f_subrubro != "Todos" and f_subrubro != "" and d.get("subrubro") != f_subrubro: mostrar = False
            if f_reciente:
                if d.get("creado_en") is None or d.get("creado_en").date() != hoy: mostrar = False

            if mostrar:
                self._filtered_indices.append(i)

        self.current_page = 0
        self._render_page()

    def _render_page(self):
        try:
            self.tbl.itemChanged.disconnect(self._on_item_changed)
        except Exception:
            pass

        self.tbl.setUpdatesEnabled(False)
        self.tbl.setSortingEnabled(False)
        self.tbl.setRowCount(0)

        start_idx = self.current_page * self.page_size
        end_idx = min(start_idx + self.page_size, len(self._filtered_indices))
        
        max_page = max(1, (len(self._filtered_indices) + self.page_size - 1) // self.page_size)
        self.lbl_page.setText(f"Página {self.current_page + 1} de {max_page}")

        for page_row, idx in enumerate(self._filtered_indices[start_idx:end_idx]):
            self.tbl.insertRow(page_row)
            d = self._datos_filtro[idx]

            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            if hasattr(self, '_selected_ids') and d["id"] in self._selected_ids:
                chk.setCheckState(Qt.CheckState.Checked)
            else:
                chk.setCheckState(Qt.CheckState.Unchecked)
            self.tbl.setItem(page_row, 0, chk)

            it_id = QTableWidgetItem(str(d["id"]))
            it_id.setData(Qt.ItemDataRole.UserRole, d["id"])
            it_id.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.tbl.setItem(page_row, 1, it_id)

            it_marca = QTableWidgetItem(d.get("marca") or "")
            it_marca.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.tbl.setItem(page_row, 2, it_marca)

            it_nombre = QTableWidgetItem(d.get("nombre") or "")
            it_nombre.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.tbl.setItem(page_row, 3, it_nombre)

            it_cb = QTableWidgetItem(d.get("cb") or "")
            it_cb.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.tbl.setItem(page_row, 4, it_cb)

        self.tbl.resizeColumnsToContents()
        self.tbl.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.tbl.setUpdatesEnabled(True)
        self.tbl.setSortingEnabled(True)
        self.tbl.itemChanged.connect(self._on_item_changed)
        
    def _on_item_changed(self, item):
        if not hasattr(self, '_selected_ids'):
            self._selected_ids = set()
            
        if item.column() == 0:
            pid = self.tbl.item(item.row(), 1).data(Qt.ItemDataRole.UserRole)
            if pid is not None:
                if item.checkState() == Qt.CheckState.Checked:
                    self._selected_ids.add(pid)
                else:
                    self._selected_ids.discard(pid)


    def _abrir_config_ticket(self):
        dlg = ConfiguracionTicketDialog(self)
        dlg.exec()

    def _get_selected_ids(self):
        if not hasattr(self, '_selected_ids'):
            self._selected_ids = set()
        return list(self._selected_ids)

    def _asignar_codigos_faltantes(self):
        count = 0
        with get_session() as s:
            prods = s.query(Producto).filter(Producto.activo == True).all()
            for p in prods:
                if not p.codigo_barras or not p.codigo_barras.strip():
                    nuevo_codigo = f"INT{p.id:06d}"
                    p.codigo_barras = nuevo_codigo
                    count += 1
            if count > 0:
                s.commit()
                QMessageBox.information(self, "Generar", f"Se generaron {count} códigos nuevos.")
                self._load_data()
            else:
                QMessageBox.information(self, "Generar", "No había productos sin código.")

    def _open_print_preview(self):
        ids = self._get_selected_ids()
        if not ids:
            QMessageBox.warning(self, "Imprimir", "Seleccione al menos un producto.")
            return

        items = []
        with get_session() as s:
            if Marca:
                q = s.query(Producto, Marca.nombre).outerjoin(Marca, Producto.marca_id == Marca.id).filter(Producto.id.in_(ids))
            else:
                q = s.query(Producto).filter(Producto.id.in_(ids))

            for row in q.all():
                if Marca:
                    try:
                        p, m_nombre = row
                    except:
                        try:
                            p = row[0]
                            m_nombre = row[1]
                        except:
                            p = row
                            m_nombre = ""
                else:
                    p = row; m_nombre = ""

                if not hasattr(p, 'codigo_barras'):
                     continue

                code = (p.codigo_barras or "").strip()
                if not code: code = f"INT{p.id:06d}"

                items.append({
                    "id": p.id,
                    "marca": m_nombre,
                    "nombre": p.nombre,
                    "code": code,
                    "equivalencia": p.codigo_equivalencia,
                    "sku": p.sku,
                    "cod_prov": p.codigo_proveedor,
                    "precio": p.precio_minorista
                })

        dlg = EtiquetasPreviewDialog(items, self)
        dlg.exec()
