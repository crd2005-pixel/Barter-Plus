from PyQt6.QtWidgets import (
    QSpinBox, QDoubleSpinBox,
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QDialog, QFormLayout, QLineEdit, QComboBox, QTabWidget
)
from PyQt6.QtCore import Qt
from services.caja_service import CajaService

class MovimientoDialog(QDialog):
    def __init__(self, tipo: str, parent=None):
        super().__init__(parent)
        self.tipo = tipo
        self.setWindowTitle(f"Registrar {tipo}")
        self.setup_ui()

    def setup_ui(self):
        layout = QFormLayout(self)

        self.txt_concepto = QLineEdit()
        self.txt_monto = QLineEdit()
        self.combo_metodo = QComboBox()
        self.combo_metodo.addItems(["Efectivo", "Tarjeta", "Transferencia"])

        layout.addRow("Concepto:", self.txt_concepto)
        layout.addRow("Monto ($):", self.txt_monto)
        layout.addRow("Método:", self.combo_metodo)

        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar")
        btn_guardar.clicked.connect(self.accept)
        btn_cancelar = QPushButton("Cancelar")
        btn_cancelar.clicked.connect(self.reject)

        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_cancelar)
        layout.addRow(btn_layout)

    def get_data(self):
        try:
            monto = float(self.txt_monto.text().strip())
        except ValueError:
            monto = 0.0
        return self.txt_concepto.text().strip(), monto, self.combo_metodo.currentText()

class CajaActualTab(QWidget):
    def __init__(self, parent_view):
        super().__init__()
        self.parent_view = parent_view
        self.caja_activa = None
        self.setup_ui()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)

        # Panel Superior
        header_layout = QHBoxLayout()
        self.lbl_estado = QLabel("Estado: DESCONOCIDO")
        self.lbl_estado.setStyleSheet("font-size: 24px; font-weight: bold;")
        self.lbl_saldo = QLabel("Saldo Actual (Efectivo): $0.00")
        self.lbl_saldo.setStyleSheet("font-size: 24px; font-weight: bold; color: green;")

        header_layout.addWidget(self.lbl_estado)
        header_layout.addStretch()
        header_layout.addWidget(self.lbl_saldo)

        main_layout.addLayout(header_layout)

        # Botonera
        btn_layout = QHBoxLayout()
        self.btn_abrir = QPushButton("Abrir Caja")
        self.btn_abrir.clicked.connect(self.abrir_caja)

        self.btn_cerrar = QPushButton("Cerrar Caja (Auditoría)")
        self.btn_cerrar.clicked.connect(self.cerrar_caja)
        self.btn_cerrar.setStyleSheet("background-color: #d9534f; color: white; font-weight: bold;")

        self.btn_ingreso = QPushButton("Ingreso de Dinero")
        self.btn_ingreso.clicked.connect(self.registrar_ingreso)

        self.btn_retiro = QPushButton("Retiro de Dinero")
        self.btn_retiro.clicked.connect(self.registrar_retiro)

        btn_layout.addWidget(self.btn_abrir)
        btn_layout.addWidget(self.btn_cerrar)
        btn_layout.addWidget(self.btn_ingreso)
        btn_layout.addWidget(self.btn_retiro)

        main_layout.addLayout(btn_layout)

        # Grilla de Movimientos
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels([
            "Hora", "Tipo", "Descripción", "Método", "Ingreso", "Egreso", "Saldo Parcial"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.cellDoubleClicked.connect(self._abrir_detalle)

        main_layout.addWidget(self.table)

    def refresh_caja(self):
        self.caja_activa = CajaService.obtener_caja_activa()
        if self.caja_activa:
            self.lbl_estado.setText("Estado: ABIERTA")
            self.lbl_estado.setStyleSheet("font-size: 24px; font-weight: bold; color: green;")
            saldo = CajaService.calcular_saldo_efectivo(self.caja_activa.id)
            self.lbl_saldo.setText("Saldo Actual (Efectivo): ****** [Oculto por Auditoría]")

            self.btn_abrir.setEnabled(False)
            self.btn_cerrar.setEnabled(True)
            self.btn_ingreso.setEnabled(True)
            self.btn_retiro.setEnabled(True)

            self.cargar_movimientos()
        else:
            self.lbl_estado.setText("Estado: CERRADA")
            self.lbl_estado.setStyleSheet("font-size: 24px; font-weight: bold; color: red;")
            self.lbl_saldo.setText("Saldo Actual (Efectivo): $0.00")

            self.btn_abrir.setEnabled(True)
            self.btn_cerrar.setEnabled(False)
            self.btn_ingreso.setEnabled(False)
            self.btn_retiro.setEnabled(False)

            self.table.setRowCount(0)

    def _aplicar_arqueo_ciego(self):
        try:
            rol_actual = getattr(self, 'rol_usuario', 'Mostrador')
            # Ocultar siempre si no es admin, sin importar la recarga
            es_admin = (rol_actual == 'Administrador')

            # Buscar la columna por texto para ser a prueba de fallos
            for col in range(self.table.columnCount()):
                item = self.table.horizontalHeaderItem(col)
                if item and "Saldo Parcial" in item.text():
                    self.table.setColumnHidden(col, not es_admin)
        except Exception as e:
            pass

    def cargar_movimientos(self):
        if not self.caja_activa:
            return

        movimientos = CajaService.obtener_movimientos(self.caja_activa.id)
        self.table.setRowCount(len(movimientos))

        saldo_parcial = 0.0

        for row, mov in enumerate(movimientos):
            if mov.metodo == "Efectivo":
                if mov.tipo == "Ingreso":
                    saldo_parcial += mov.monto
                else:
                    saldo_parcial -= mov.monto

            hora_str = mov.fecha.strftime("%H:%M:%S")
            item_hora = QTableWidgetItem(hora_str)
            if getattr(mov, 'venta_id', None):
                item_hora.setData(Qt.ItemDataRole.UserRole, mov.venta_id)
            self.table.setItem(row, 0, item_hora)
            self.table.setItem(row, 1, QTableWidgetItem(mov.tipo))
            self.table.setItem(row, 2, QTableWidgetItem(mov.concepto))
            self.table.setItem(row, 3, QTableWidgetItem(mov.metodo))

            if mov.tipo == "Ingreso":
                self.table.setItem(row, 4, QTableWidgetItem(f"${mov.monto:.2f}"))
                self.table.setItem(row, 5, QTableWidgetItem("-"))
            else:
                self.table.setItem(row, 4, QTableWidgetItem("-"))
                self.table.setItem(row, 5, QTableWidgetItem(f"${mov.monto:.2f}"))

            self.table.setItem(row, 6, QTableWidgetItem(f"${saldo_parcial:.2f}"))
            
        self._aplicar_arqueo_ciego()
        self.table.scrollToBottom()

    def _abrir_detalle(self, row, col):
        item_hora = self.table.item(row, 0)
        if not item_hora: return
        venta_id = item_hora.data(Qt.ItemDataRole.UserRole)
        if not venta_id: return

        from ui.components.dialogs import DetalleVentaDialog
        dlg = DetalleVentaDialog(venta_id, self)
        dlg.exec()

    def abrir_caja(self):
        monto, ok = QInputDialog.getDouble(
            self, "Abrir Caja", "Ingrese monto inicial de cambio ($):", 0, 0, 10000000, 2
        )
        if ok:
            try:
                CajaService.abrir_caja(monto)
                QMessageBox.information(self, "Caja", "Caja abierta exitosamente.")
                self.parent_view.refresh_all()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def cerrar_caja(self):
        if not self.caja_activa:
            return

        from ui.components.dialogs import DeclaracionCiegaDialog, PanelArqueoCajaDialog
        from PyQt6.QtWidgets import QDialog
        
        # Etapa 1: Declaracion Ciega
        dlg_ciega = DeclaracionCiegaDialog(self)
        if dlg_ciega.exec() != QDialog.DialogCode.Accepted:
            return
            
        monto_declarado = dlg_ciega.get_monto()
        
        # Etapa 2: Auditoria y Cierre (Bloqueado)
        dialog = PanelArqueoCajaDialog(self.caja_activa.id, monto_declarado, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.parent_view.refresh_all()

    def registrar_ingreso(self):
        dialog = MovimientoDialog("Ingreso", self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            concepto, monto, metodo = dialog.get_data()
            if concepto and monto > 0:
                try:
                    CajaService.registrar_movimiento(self.caja_activa.id, "Ingreso", concepto, monto, metodo)
                    self.parent_view.refresh_all()
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))
            else:
                QMessageBox.warning(self, "Validación", "Debe ingresar un concepto y un monto válido mayor a 0.")

    def registrar_retiro(self):
        dialog = MovimientoDialog("Egreso", self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            concepto, monto, metodo = dialog.get_data()
            if concepto and monto > 0:
                try:
                    CajaService.registrar_movimiento(self.caja_activa.id, "Egreso", concepto, monto, metodo)
                    self.parent_view.refresh_all()
                except Exception as e:
                    QMessageBox.critical(self, "Error", str(e))
            else:
                QMessageBox.warning(self, "Validación", "Debe ingresar un concepto y un monto válido mayor a 0.")

class HistorialCajaTab(QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()

    def _exportar_pdf(self):
        from PyQt6.QtWidgets import QFileDialog, QMessageBox
        from utils.export_utils import ExportUtils
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Guardar Reporte PDF", f"Reporte_{self.__class__.__name__}.pdf", "Archivos PDF (*.pdf)"
        )
        if filepath:
            try:
                ExportUtils.exportar_tabla_a_pdf(self.table, "Historial de Caja - Reporte Oficial", filepath)
                QMessageBox.information(self, "Éxito", "El PDF se exportó correctamente.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"No se pudo exportar: {str(e)}")

    def setup_ui(self):
        layout = QVBoxLayout(self)

        top_layout = QHBoxLayout()
        self.btn_refresh = QPushButton("Actualizar Historial")
        self.btn_refresh.clicked.connect(self.cargar_historial)
        
        self.btn_exportar_pdf = QPushButton("Exportar a PDF")
        self.btn_exportar_pdf.setStyleSheet("background-color: #c0392b; color: white; font-weight: bold;")
        self.btn_exportar_pdf.clicked.connect(self._exportar_pdf)
        
        top_layout.addWidget(self.btn_refresh)
        top_layout.addStretch()
        top_layout.addWidget(self.btn_exportar_pdf)
        
        layout.addLayout(top_layout)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels([
            "ID Caja", "Fecha Apertura", "Fecha Cierre", "Saldo Inicial",
            "Saldo Final (Sistema)", "Saldo Físico (Declarado)", "Diferencia", "Estado"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.cellDoubleClicked.connect(self._abrir_detalle_caja)

        layout.addWidget(self.table)

    def _abrir_detalle_caja(self, row, col):
        item_id = self.table.item(row, 0)
        if not item_id: return
        caja_id = item_id.data(Qt.ItemDataRole.UserRole)
        if not caja_id: return

        from ui.components.dialogs import DetalleCajaDialog
        dlg = DetalleCajaDialog(caja_id, self)
        dlg.exec()

    def cargar_historial(self):
        cajas = CajaService.obtener_historial_cajas()
        self.table.setRowCount(len(cajas))

        for row, caja in enumerate(cajas):
            item_id = QTableWidgetItem(str(caja.id))
            item_id.setData(Qt.ItemDataRole.UserRole, caja.id)
            self.table.setItem(row, 0, item_id)

            apertura_str = caja.fecha_apertura.strftime("%Y-%m-%d %H:%M:%S")
            self.table.setItem(row, 1, QTableWidgetItem(apertura_str))

            cierre_str = caja.fecha_cierre.strftime("%Y-%m-%d %H:%M:%S") if caja.fecha_cierre else "-"
            self.table.setItem(row, 2, QTableWidgetItem(cierre_str))

            self.table.setItem(row, 3, QTableWidgetItem(f"${caja.saldo_inicial:.2f}"))
            self.table.setItem(row, 4, QTableWidgetItem(f"${caja.saldo_final_esperado:.2f}"))
            self.table.setItem(row, 5, QTableWidgetItem(f"${caja.saldo_final_real:.2f}"))

            item_dif = QTableWidgetItem(f"${caja.diferencia:.2f}")
            if caja.diferencia < 0:
                item_dif.setForeground(Qt.GlobalColor.red)
            elif caja.diferencia > 0:
                item_dif.setForeground(Qt.GlobalColor.blue)
            self.table.setItem(row, 6, item_dif)

            item_estado = QTableWidgetItem(caja.estado)
            if caja.estado == "Abierta":
                item_estado.setForeground(Qt.GlobalColor.darkGreen)
            self.table.setItem(row, 7, item_estado)


class ConfiguracionTarjetasTab(QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.cargar_datos()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # Controles superiores
        form_layout = QFormLayout()
        self.combo_banco = QComboBox()
        self.combo_banco.addItems(["Visa", "Mastercard", "Cabal", "Naranja", "American Express", "MercadoPago", "Otro"])

        self.spin_cuotas = QSpinBox()
        self.spin_cuotas.setRange(1, 48)
        self.spin_interes = QDoubleSpinBox()
        self.spin_interes.setRange(0.0, 500.0)
        self.spin_interes.setSuffix(" %")
        self.spin_dias = QSpinBox()
        self.spin_dias.setRange(0, 365)
        self.spin_dias.setSuffix(" días")

        form_layout.addRow("Banco / Tarjeta:", self.combo_banco)
        form_layout.addRow("Cantidad de Cuotas:", self.spin_cuotas)
        form_layout.addRow("Porcentaje Recargo/Interés:", self.spin_interes)
        form_layout.addRow("Días Hábiles de Acreditación:", self.spin_dias)

        btn_layout = QHBoxLayout()
        self.btn_guardar = QPushButton("Guardar Plan")
        self.btn_guardar.setStyleSheet("background-color: #28a745; color: white; font-weight: bold;")
        self.btn_guardar.clicked.connect(self.guardar_plan)
        self.btn_eliminar = QPushButton("Eliminar Seleccionado")
        self.btn_eliminar.setStyleSheet("background-color: #dc3545; color: white; font-weight: bold;")
        self.btn_eliminar.clicked.connect(self.eliminar_plan)

        btn_layout.addWidget(self.btn_guardar)
        btn_layout.addWidget(self.btn_eliminar)

        layout.addLayout(form_layout)
        layout.addLayout(btn_layout)

        # Grilla de Configuraciones
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels([
            "ID", "Banco / Tarjeta", "Cuotas", "Interés (%)", "Acreditación (Días)"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)

        layout.addWidget(self.table)

    def cargar_datos(self):
        from database.conexion import get_session
        from database.models import ConfiguracionTarjeta
        with get_session() as session:
            planes = session.query(ConfiguracionTarjeta).all()
            self.table.setRowCount(len(planes))
            for row, plan in enumerate(planes):
                self.table.setItem(row, 0, QTableWidgetItem(str(plan.id)))
                self.table.setItem(row, 1, QTableWidgetItem(plan.banco_tarjeta))
                self.table.setItem(row, 2, QTableWidgetItem(str(plan.cuotas)))
                self.table.setItem(row, 3, QTableWidgetItem(f"{plan.porcentaje_interes:.2f}%"))
                self.table.setItem(row, 4, QTableWidgetItem(str(plan.dias_acreditacion)))

    def guardar_plan(self):
        banco = self.combo_banco.currentText()
        if not banco:
            QMessageBox.warning(self, "Error", "El nombre del Banco/Tarjeta es obligatorio.")
            return

        from database.conexion import get_session
        from database.models import ConfiguracionTarjeta
        try:
            with get_session() as session:
                nuevo = ConfiguracionTarjeta(
                    banco_tarjeta=banco,
                    cuotas=self.spin_cuotas.value(),
                    porcentaje_interes=self.spin_interes.value(),
                    dias_acreditacion=self.spin_dias.value()
                )
                session.add(nuevo)
                session.commit()
            self.cargar_datos()
            self.combo_banco.setCurrentIndex(0)
            self.spin_cuotas.setValue(1)
            self.spin_interes.setValue(0.0)
            self.spin_dias.setValue(0)
            QMessageBox.information(self, "Éxito", "Plan guardado correctamente.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al guardar: {e}")

    def eliminar_plan(self):
        fila = self.table.currentRow()
        if fila < 0:
            return
        plan_id = int(self.table.item(fila, 0).text())

        reply = QMessageBox.question(self, "Confirmar", "¿Eliminar este plan de tarjeta?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            from database.conexion import get_session
            from database.models import ConfiguracionTarjeta
            try:
                with get_session() as session:
                    plan = session.get(ConfiguracionTarjeta, plan_id)
                    if plan:
                        session.delete(plan)
                        session.commit()
                self.cargar_datos()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Error al eliminar: {e}")

class CajaView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.refresh_all()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()

        self.tab_actual = CajaActualTab(self)
        self.tab_historial = HistorialCajaTab()
        self.tab_tarjetas = ConfiguracionTarjetasTab()

        self.tabs.addTab(self.tab_actual, "Caja Actual")
        self.tabs.addTab(self.tab_historial, "Historial / Auditoría")
        self.tabs.addTab(self.tab_tarjetas, "Configuración de Tarjetas")

        layout.addWidget(self.tabs)

    def refresh_all(self):
        self.tab_actual.refresh_caja()
        self.tab_historial.cargar_historial()

    def showEvent(self, event):
        super().showEvent(event)
        self.refresh_all()
